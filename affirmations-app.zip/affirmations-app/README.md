# Affirmation Sanctuary

Your personal cloud-powered daily affirmation app.

## Features

- 4 cloud-hosted voice sessions (Morning, Afternoon, Evening, Bonus)
- Daily wisdom rotation with 33+ quotes
- Add custom affirmations via URL
- Persistent settings on your device
- Native audio player (works on iOS/Android/Desktop)
- Add to Home Screen support

## Deploy to Vercel

### Quick deploy (drag and drop):

1. Go to https://vercel.com
2. Sign up / log in
3. Click "Add New" → "Project"
4. Drag this folder onto the page
5. Click "Deploy"

You'll get a free URL like `your-app.vercel.app`

### Add to iPhone Home Screen:

1. Open the URL in Safari
2. Tap Share button (bottom)
3. Tap "Add to Home Screen"
4. Name it "Affirmations"
5. Tap Add

Now it works as a real app icon!

## Customize

Edit `index.html` to:
- Change Cloudinary URLs (top of `<script>` block)
- Add/edit daily wisdom quotes
- Update affirmation session details
